Este trabajo ha sido realizado por:
Adrián Ayabarrena
Alan García
Adrián López

En la carpeta GestorPeliculas se encuentra todo el proyecto.
El repositorio de GitHub se encuentra en la siguiente dirección:
https://github.com/AliOlixx/GestorPeliculas

Además, en la carpeta builds, dentro de la carpeta del proyecto, hay un archivo ejecutable para testar la aplicación (Como el archivo .jar es demasiado pesado para enviarlo por la app de eGela, no está adjuntado pero sí se encuentra en el GitHub).